package routers

func (router RouterGroup) AssignmentRouter() {
}
