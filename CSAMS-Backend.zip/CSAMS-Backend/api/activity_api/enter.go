package activity_api

type ActivityApi struct {
}
