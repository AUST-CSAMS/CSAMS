package image_api

type ImageApi struct {
}
