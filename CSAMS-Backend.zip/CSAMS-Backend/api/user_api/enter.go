package user_api

type UserApi struct {
}
