package assignment_api

type AssignmentApi struct {
}
