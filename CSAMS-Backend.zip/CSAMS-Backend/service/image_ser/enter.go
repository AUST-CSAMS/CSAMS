package image_ser

type ImageService struct {
}
