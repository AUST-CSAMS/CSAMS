package user_ser

type UserService struct {
}
